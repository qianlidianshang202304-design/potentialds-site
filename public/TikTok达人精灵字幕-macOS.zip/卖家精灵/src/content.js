(function initializeTikTokSubtitlePanel() {
  "use strict";

  if (window.top !== window || document.getElementById("ttds-root")) return;

  const DEFAULT_SETTINGS = {
    autoOpen: true,
    autoTranslate: false,
    panelEnabled: true
  };

  const state = {
    copyMode: false,
    cues: [],
    currentUrl: location.href,
    destroyed: false,
    loading: false,
    open: false,
    pendingRefresh: false,
    selectedTrack: "",
    settings: { ...DEFAULT_SETTINGS },
    tracks: [],
    translatedCues: null
  };

  const ui = createInterface();
  bindInterface();
  boot();

  async function boot() {
    state.settings = await getSettings();
    applySettings();
    watchNavigation();
    window.setInterval(updateActiveCue, 300);
    if (state.settings.panelEnabled) await refreshForPage();
  }

  function createElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function createInterface() {
    const root = createElement("div", "ttds-root");
    root.id = "ttds-root";

    const toggle = createElement("button", "ttds-toggle", "CC");
    toggle.type = "button";
    toggle.title = "打开字幕面板";
    toggle.setAttribute("aria-label", "打开字幕面板");

    const panel = createElement("aside", "ttds-panel");
    panel.setAttribute("aria-label", "TikTok 字幕面板");

    const header = createElement("header", "ttds-header");
    const identity = createElement("div", "ttds-identity");
    const mark = createElement("div", "ttds-mark", "CC");
    const heading = createElement("div", "ttds-heading");
    const title = createElement("strong", "ttds-title", "达人精灵·字幕");
    const meta = createElement("span", "ttds-meta", "等待读取");
    const close = createElement("button", "ttds-close", "×");
    close.type = "button";
    close.title = "收起字幕面板";
    close.setAttribute("aria-label", "收起字幕面板");
    heading.append(title, meta);
    identity.append(mark, heading);
    header.append(identity, close);

    const toolbar = createElement("div", "ttds-toolbar");
    const trackSelect = createElement("select", "ttds-select");
    trackSelect.setAttribute("aria-label", "字幕语言");
    const translate = createElement("button", "ttds-button ttds-button-primary", "翻译中文");
    translate.type = "button";
    const copy = createElement("button", "ttds-button", "选择复制");
    copy.type = "button";
    const reload = createElement("button", "ttds-button-icon", "↻");
    reload.type = "button";
    reload.title = "重新读取字幕或提取当前音轨";
    reload.setAttribute("aria-label", "重新读取字幕或提取当前音轨");
    toolbar.append(trackSelect, translate, copy, reload);

    const status = createElement("div", "ttds-status");
    status.setAttribute("role", "status");
    const statusDot = createElement("span", "ttds-status-dot");
    const statusText = createElement("span", "ttds-status-text", "正在检查当前视频…");
    status.append(statusDot, statusText);

    const copyView = createElement("div", "ttds-copy-view");
    const copyArea = createElement("textarea", "ttds-copy-area");
    copyArea.readOnly = true;
    copyArea.spellcheck = false;
    copyArea.setAttribute("aria-label", "可选择复制的字幕文本");
    const copyActions = createElement("div", "ttds-copy-actions");
    const copyHint = createElement("span", "ttds-copy-hint", "已全选字幕文本");
    const copySelected = createElement("button", "ttds-button ttds-button-primary", "复制所选");
    copySelected.type = "button";
    const copyAll = createElement("button", "ttds-button", "全选");
    copyAll.type = "button";
    copyActions.append(copyHint, copyAll, copySelected);
    copyView.append(copyArea, copyActions);

    const list = createElement("div", "ttds-list");
    const empty = createElement("div", "ttds-empty");
    const emptyTitle = createElement("strong", "", "暂未读取到字幕");
    const emptyText = createElement(
      "span",
      "",
      "请确认当前视频提供字幕，或在视频播放后重新读取。"
    );
    empty.append(emptyTitle, emptyText);
    list.append(empty);

    panel.append(header, toolbar, status, copyView, list);
    root.append(toggle, panel);
    document.documentElement.append(root);

    return {
      close,
      copy,
      copyAll,
      copyArea,
      copyHint,
      copySelected,
      copyView,
      empty,
      list,
      meta,
      panel,
      reload,
      root,
      status,
      statusText,
      toggle,
      trackSelect,
      translate
    };
  }

  function bindInterface() {
    ui.toggle.addEventListener("click", () => setOpen(true));
    ui.close.addEventListener("click", () => setOpen(false));
    ui.reload.addEventListener("click", () => refreshForPage(true));
    ui.trackSelect.addEventListener("change", () => loadTrack(ui.trackSelect.value));
    ui.translate.addEventListener("click", translateCurrentCues);
    ui.copy.addEventListener("click", () => setCopyMode(!state.copyMode));
    ui.copyAll.addEventListener("click", selectAllTranscript);
    ui.copySelected.addEventListener("click", copySelectedTranscript);
    ui.copyArea.addEventListener("select", updateCopySelectionStatus);
    ui.copyArea.addEventListener("keyup", updateCopySelectionStatus);
    ui.panel.addEventListener("click", (event) => event.stopPropagation());
    ui.panel.addEventListener("pointerdown", (event) => event.stopPropagation());

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      for (const key of Object.keys(DEFAULT_SETTINGS)) {
        if (changes[key]) state.settings[key] = changes[key].newValue;
      }
      applySettings();
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message?.type !== "OPEN_PANEL") return false;
      if (!state.settings.panelEnabled) {
        state.settings.panelEnabled = true;
        chrome.storage.sync.set({ panelEnabled: true });
      }
      setOpen(true);
      if (!state.cues.length && !state.loading) refreshForPage(true);
      sendResponse({ ok: true });
      return false;
    });
  }

  function applySettings() {
    ui.root.classList.toggle("ttds-disabled", !state.settings.panelEnabled);
    if (!state.settings.panelEnabled) {
      setOpen(false);
      return;
    }
    if (state.settings.autoOpen && !state.open) setOpen(true);
  }

  function setOpen(open) {
    state.open = Boolean(open && state.settings.panelEnabled);
    ui.root.classList.toggle("ttds-open", state.open);
    ui.panel.setAttribute("aria-hidden", String(!state.open));
  }

  function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => resolve(settings));
    });
  }

  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        if (!response?.ok) {
          reject(new Error(response?.error || "扩展后台未返回有效结果"));
          return;
        }
        resolve(response);
      });
    });
  }

  function watchNavigation() {
    let lastUrl = location.href;
    const check = () => {
      if (location.href === lastUrl) return;
      lastUrl = location.href;
      state.currentUrl = lastUrl;
      window.setTimeout(() => refreshForPage(), 450);
    };
    const observer = new MutationObserver(check);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.setInterval(check, 800);
  }

  async function refreshForPage(userInitiated = false) {
    if (!state.settings.panelEnabled) return;
    if (state.loading) {
      state.pendingRefresh = true;
      return;
    }
    state.loading = true;
    state.pendingRefresh = false;
    const requestedUrl = location.href;
    setCopyMode(false);
    state.cues = [];
    state.translatedCues = null;
    renderCues();
    setStatus("loading", "正在寻找当前视频的字幕…");
    ui.reload.disabled = true;
    ui.translate.disabled = true;
    ui.copy.disabled = true;

    try {
      let tracks = discoverTracks();
      if (!tracks.length) {
        await delay(userInitiated ? 300 : 900);
        tracks = discoverTracks();
      }
      state.tracks = tracks;
      renderTrackOptions();
      if (!tracks.length) {
        if (!userInitiated) {
          setStatus("empty", "无原生字幕；点击刷新可提取当前视频音轨");
          ui.meta.textContent = "可提取音轨";
          return;
        }
        const media = discoverCurrentMedia();
        if (!media) {
          setStatus("error", "未找到当前正在播放的 TikTok 视频媒体地址");
          ui.meta.textContent = "音轨提取失败";
          return;
        }
        await transcribeCurrentAudio(media, requestedUrl);
        return;
      }

      const preferred = choosePreferredTrack(tracks);
      state.selectedTrack = preferred.id;
      ui.trackSelect.value = preferred.id;
      await loadTrack(preferred.id);
    } finally {
      state.loading = false;
      ui.reload.disabled = false;
      if (state.pendingRefresh || location.href !== requestedUrl) {
        state.pendingRefresh = false;
        window.setTimeout(() => refreshForPage(), 100);
      }
    }
  }

  function getActiveVideo() {
    const videos = [...document.querySelectorAll("video")];
    const scored = videos.map((video) => {
      const rect = video.getBoundingClientRect();
      const visibleWidth = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0));
      const visibleHeight = Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
      const visibleArea = visibleWidth * visibleHeight;
      const playingBonus = !video.paused && !video.ended ? 1_000_000_000 : 0;
      return { video, score: playingBonus + visibleArea };
    });
    return scored.sort((left, right) => right.score - left.score)[0]?.video || null;
  }

  function findHydrationItem(data, videoId) {
    const detailItem = data?.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct;
    if (detailItem && (!videoId || String(detailItem.id || detailItem.awemeId) === videoId)) {
      return detailItem;
    }
    if (!videoId) return detailItem || null;

    const seen = new WeakSet();
    let matched = null;
    const visit = (value, depth) => {
      if (matched || !value || typeof value !== "object" || depth > 25 || seen.has(value)) return;
      seen.add(value);
      const itemId = String(value.id || value.awemeId || value.aweme_id || "");
      if (itemId === videoId && value.video) {
        matched = value;
        return;
      }
      for (const child of Object.values(value)) visit(child, depth + 1);
    };
    visit(data, 0);
    return matched;
  }

  function discoverCurrentMedia() {
    const video = getActiveVideo();
    if (!video) return null;
    const articleLink = video
      .closest("article")
      ?.querySelector("a[href*='/video/']")
      ?.getAttribute("href");
    const videoId =
      SubtitleUtils.extractVideoId(articleLink) || SubtitleUtils.extractVideoId(location.href);
    if (!videoId) return null;

    const directCandidates = [
      video.currentSrc,
      video.src,
      ...[...video.querySelectorAll("source")].map((source) => source.src)
    ];
    const mediaUrls = directCandidates.filter(
      (url) => typeof url === "string" && url.startsWith("https://")
    );

    for (const script of document.querySelectorAll(
      "script#__UNIVERSAL_DATA_FOR_REHYDRATION__, script#SIGI_STATE"
    )) {
      try {
        const data = JSON.parse(script.textContent || "{}");
        const item = findHydrationItem(data, videoId);
        mediaUrls.push(...SubtitleUtils.findTikTokMediaUrls(item));
      } catch {
        // Ignore malformed hydration data and continue with the next source.
      }
    }

    const uniqueUrls = [...new Set(mediaUrls)];
    if (!uniqueUrls.length) return null;
    return { mediaUrl: uniqueUrls[0], mediaUrls: uniqueUrls.slice(0, 16), pageUrl: location.href, videoId };
  }

  async function transcribeCurrentAudio(media, requestedUrl) {
    renderAudioTrackOption();
    setStatus("loading", "正在提取当前视频音轨并识别，首次使用会下载 Whisper 模型…");
    ui.meta.textContent = "音轨识别中";
    try {
      const response = await sendMessage({ type: "TRANSCRIBE_AUDIO", ...media });
      if (location.href !== requestedUrl) return;
      state.cues = response.cues || [];
      state.translatedCues = response.translations || state.cues.map((cue) => cue.text);
      state.selectedTrack = "audio-whisper";
      renderAudioTrackOption(response.language);
      renderCues();
      ui.meta.textContent = `${state.cues.length} 段音轨文字`;
      ui.translate.disabled = !state.cues.length;
      ui.translate.textContent = "重新翻译";
      ui.copy.disabled = !state.cues.length;
      const cacheLabel = response.cached ? "已从本地缓存读取" : "已完成本地音轨识别";
      if (response.failed) {
        setStatus(
          "warning",
          `${cacheLabel}；${response.translated} 段翻译成功，${response.failed} 段保留原文`
        );
      } else {
        setStatus("success", `${cacheLabel}并翻译 ${response.translated} 段`);
      }
    } catch (error) {
      state.cues = [];
      state.translatedCues = null;
      renderCues();
      ui.meta.textContent = "音轨识别失败";
      setStatus("error", error.message);
    }
  }

  function discoverTracks() {
    const found = [];
    const add = (rawUrl, metadata = {}) => {
      if (typeof rawUrl !== "string" || !rawUrl.trim()) return;
      let url;
      try {
        url = new URL(rawUrl.replace(/\\u002F/gi, "/"), location.href).href;
      } catch {
        return;
      }
      if (!url.startsWith("https://")) return;
      const duplicate = found.find((track) => track.url === url);
      if (duplicate) {
        Object.assign(duplicate, compactMetadata(metadata));
        duplicate.language = SubtitleUtils.formatLanguageLabel(duplicate.language, duplicate.languageCode);
        return;
      }
      found.push({
        id: `track-${found.length}`,
        url,
        language: SubtitleUtils.formatLanguageLabel(metadata.language, metadata.languageCode),
        languageCode: metadata.languageCode || "",
        source: metadata.source || "TikTok"
      });
    };

    document.querySelectorAll("video track[kind='captions'], video track[kind='subtitles']").forEach((track) => {
      add(track.src || track.getAttribute("src"), {
        language: track.label,
        languageCode: track.srclang,
        source: "player"
      });
    });

    document
      .querySelectorAll("script#__UNIVERSAL_DATA_FOR_REHYDRATION__, script#SIGI_STATE")
      .forEach((script) => {
        try {
          inspectHydrationData(JSON.parse(script.textContent || "{}"), add);
        } catch {
          inspectRawScript(script.textContent || "", add);
        }
      });

    performance.getEntriesByType("resource").forEach((entry) => {
      const name = entry.name || "";
      if (/(?:subtitle|caption|\.vtt(?:\?|$)|\.srt(?:\?|$))/i.test(name)) {
        add(name, { source: "network" });
      }
    });

    return found;
  }

  function inspectHydrationData(data, add) {
    const seen = new WeakSet();
    const visit = (value, path, depth) => {
      if (!value || typeof value !== "object" || depth > 30 || seen.has(value)) return;
      seen.add(value);

      if (!Array.isArray(value)) {
        const url = value.Url || value.url || value.Src || value.src || value.UrlList?.[0];
        const keys = Object.keys(value).join(" ");
        const context = `${path} ${keys}`;
        if (url && /subtitle|caption/i.test(context)) {
          add(url, {
            language:
              value.LanguageCodeName || value.languageName || value.displayName || value.Name || value.label,
            languageCode:
              value.LanguageCode || value.languageCode || value.Locale || value.locale || value.srclang,
            source: value.Source || value.source || "hydration"
          });
        }
      }

      for (const [key, child] of Object.entries(value)) {
        if (typeof child === "string" && /^https:\/\//i.test(child) && /subtitle|caption/i.test(path + key)) {
          add(child, { source: "hydration" });
        } else {
          visit(child, `${path}.${key}`, depth + 1);
        }
      }
    };
    visit(data, "root", 0);
  }

  function inspectRawScript(text, add) {
    const pattern = /["'](?:Url|url)["']\s*:\s*["'](https:[^"']+)["']/gi;
    let match;
    while ((match = pattern.exec(text))) {
      const nearby = text.slice(Math.max(0, match.index - 400), match.index + match[0].length + 400);
      if (/subtitle|caption/i.test(nearby)) add(match[1].replace(/\\\//g, "/"), { source: "page" });
    }
  }

  function compactMetadata(metadata) {
    return Object.fromEntries(
      Object.entries(metadata).filter(([, value]) => value !== undefined && value !== null && value !== "")
    );
  }

  function choosePreferredTrack(tracks) {
    const selected = tracks.find((track) => /^(en|en-|eng|english)/i.test(`${track.languageCode} ${track.language}`));
    return selected || tracks[0];
  }

  function renderTrackOptions() {
    ui.trackSelect.replaceChildren();
    if (!state.tracks.length) {
      const option = createElement("option", "", "无字幕轨道");
      option.value = "";
      ui.trackSelect.append(option);
      ui.trackSelect.disabled = true;
      return;
    }

    state.tracks.forEach((track, index) => {
      const option = createElement("option", "", track.language || `字幕 ${index + 1}`);
      option.value = track.id;
      ui.trackSelect.append(option);
    });
    ui.trackSelect.disabled = state.tracks.length < 2;
  }

  function renderAudioTrackOption(language = "") {
    ui.trackSelect.replaceChildren();
    const label = language === "es" ? "Español 音轨 / 本地 Whisper" : "当前音轨 / 本地 Whisper";
    const option = createElement("option", "", label);
    option.value = "audio-whisper";
    ui.trackSelect.append(option);
    ui.trackSelect.value = "audio-whisper";
    ui.trackSelect.disabled = true;
  }

  async function loadTrack(trackId) {
    const track = state.tracks.find((candidate) => candidate.id === trackId);
    if (!track) return;
    state.selectedTrack = track.id;
    state.translatedCues = null;
    setCopyMode(false);
    setStatus("loading", `正在读取 ${track.language}字幕…`);
    ui.translate.disabled = true;
    ui.copy.disabled = true;

    try {
      const response = await sendMessage({ type: "FETCH_SUBTITLE", url: track.url });
      state.cues = response.cues || [];
      renderCues();
      ui.meta.textContent = `${state.cues.length} 条字幕`;
      setStatus("success", `已读取 ${track.language}字幕`);
      ui.translate.disabled = !state.cues.length;
      ui.copy.disabled = !state.cues.length;
      if (state.settings.autoTranslate && state.cues.length) await translateCurrentCues();
    } catch (error) {
      state.cues = [];
      renderCues();
      ui.meta.textContent = "读取失败";
      setStatus("error", error.message);
    }
  }

  async function translateCurrentCues() {
    if (!state.cues.length || ui.translate.disabled) return;
    ui.translate.disabled = true;
    ui.translate.textContent = "翻译中…";
    setStatus("loading", `正在翻译 ${state.cues.length} 条字幕…`);

    try {
      const response = await sendMessage({ type: "TRANSLATE_CUES", cues: state.cues });
      state.translatedCues = response.translations;
      renderCues();
      updateCopyText();
      if (response.failed) {
        setStatus(
          "warning",
          `${response.translated} 条翻译成功，${response.failed} 条已回退显示原字幕`
        );
      } else {
        setStatus("success", `已翻译 ${response.translated} 条字幕`);
      }
    } catch (error) {
      state.translatedCues = state.cues.map((cue) => cue.text);
      renderCues();
      updateCopyText();
      setStatus("warning", `翻译失败，已保留原字幕：${error.message}`);
    } finally {
      ui.translate.disabled = false;
      ui.translate.textContent = "重新翻译";
    }
  }

  function renderCues() {
    ui.list.replaceChildren();
    if (!state.cues.length) {
      ui.list.append(ui.empty);
      return;
    }

    const fragment = document.createDocumentFragment();
    state.cues.forEach((cue, index) => {
      const row = createElement("button", "ttds-cue");
      row.type = "button";
      row.dataset.index = String(index);
      row.dataset.start = String(cue.start);
      row.title = `跳转到 ${SubtitleUtils.formatTimestamp(cue.start)}`;
      const time = createElement("span", "ttds-time", SubtitleUtils.formatTimestamp(cue.start));
      const copy = createElement("span", "ttds-cue-copy");
      const translated = state.translatedCues?.[index];
      if (state.translatedCues) {
        copy.append(createElement("span", "ttds-translation", translated || cue.text));
        if (translated && translated !== cue.text) {
          copy.append(createElement("span", "ttds-original", cue.text));
        }
      } else {
        copy.append(createElement("span", "ttds-original-only", cue.text));
      }
      row.append(time, copy);
      row.addEventListener("click", () => seekVideo(cue.start));
      fragment.append(row);
    });
    ui.list.append(fragment);
  }

  function seekVideo(seconds) {
    const videos = [...document.querySelectorAll("video")].filter(
      (video) => video.offsetWidth > 0 && video.offsetHeight > 0
    );
    const video = videos.sort((left, right) => right.offsetWidth * right.offsetHeight - left.offsetWidth * left.offsetHeight)[0];
    if (!video) {
      setStatus("warning", "未找到正在显示的视频播放器");
      return;
    }
    video.currentTime = Math.min(seconds, Number.isFinite(video.duration) ? video.duration : seconds);
    video.play().catch(() => {});
  }

  function updateActiveCue() {
    if (!state.open || !state.cues.length) return;
    const video = [...document.querySelectorAll("video")].find(
      (candidate) => candidate.offsetWidth > 0 && candidate.offsetHeight > 0 && !candidate.paused
    );
    if (!video) return;
    const activeIndex = state.cues.findIndex(
      (cue) => video.currentTime >= cue.start && video.currentTime < cue.end
    );
    ui.list.querySelectorAll(".ttds-cue-active").forEach((element) => {
      element.classList.remove("ttds-cue-active");
    });
    if (activeIndex >= 0) {
      ui.list.querySelector(`[data-index="${activeIndex}"]`)?.classList.add("ttds-cue-active");
    }
  }

  function buildTranscript() {
    return state.cues
      .map((cue, index) => {
        const displayed = state.translatedCues?.[index] || cue.text;
        return `[${SubtitleUtils.formatTimestamp(cue.start)}] ${displayed}`;
      })
      .join("\n");
  }

  function setCopyMode(enabled) {
    state.copyMode = Boolean(enabled && state.cues.length);
    ui.root.classList.toggle("ttds-copy-mode", state.copyMode);
    ui.copy.textContent = state.copyMode ? "返回字幕" : "选择复制";
    if (!state.copyMode) return;
    updateCopyText();
    window.setTimeout(selectAllTranscript, 0);
  }

  function updateCopyText() {
    if (!state.copyMode) return;
    ui.copyArea.value = buildTranscript();
  }

  function selectAllTranscript() {
    if (!state.copyMode) return;
    ui.copyArea.focus();
    ui.copyArea.select();
    updateCopySelectionStatus();
  }

  function updateCopySelectionStatus() {
    const selectedLength = Math.max(0, ui.copyArea.selectionEnd - ui.copyArea.selectionStart);
    ui.copyHint.textContent = selectedLength
      ? `已选 ${selectedLength} 个字符`
      : "请选择要复制的文本";
  }

  async function copySelectedTranscript() {
    if (!state.copyMode) return;
    const start = ui.copyArea.selectionStart;
    const end = ui.copyArea.selectionEnd;
    const text = start === end ? ui.copyArea.value : ui.copyArea.value.slice(start, end);
    try {
      await navigator.clipboard.writeText(text);
      const previous = ui.copySelected.textContent;
      ui.copySelected.textContent = "已复制";
      window.setTimeout(() => {
        ui.copySelected.textContent = previous;
      }, 1200);
    } catch {
      setStatus("error", "浏览器拒绝了剪贴板权限");
    }
  }

  function setStatus(kind, message) {
    ui.status.dataset.kind = kind;
    ui.statusText.textContent = message;
  }

  function delay(milliseconds) {
    return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  }
})();
