(function attachSubtitleUtils(root) {
  "use strict";

  const ENTITY_MAP = {
    amp: "&",
    apos: "'",
    gt: ">",
    lt: "<",
    nbsp: " ",
    quot: "\""
  };

  function decodeEntities(value) {
    return String(value || "").replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (match, entity) => {
      const normalized = entity.toLowerCase();
      if (normalized.startsWith("#x")) {
        return String.fromCodePoint(Number.parseInt(normalized.slice(2), 16));
      }
      if (normalized.startsWith("#")) {
        return String.fromCodePoint(Number.parseInt(normalized.slice(1), 10));
      }
      return ENTITY_MAP[normalized] || match;
    });
  }

  function cleanCueText(value) {
    return decodeEntities(
      String(value || "")
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]+>/g, "")
    )
      .replace(/\s+/g, " ")
      .trim();
  }

  function parseTime(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return value > 10000 ? value / 1000 : value;
    }

    const input = String(value ?? "").trim().replace(",", ".");
    if (!input) return null;
    if (/^\d+(?:\.\d+)?$/.test(input)) {
      const numeric = Number(input);
      return numeric > 10000 ? numeric / 1000 : numeric;
    }

    const parts = input.split(":").map(Number);
    if (parts.some((part) => !Number.isFinite(part))) return null;
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return null;
  }

  function parseVttOrSrt(input) {
    const normalized = String(input || "")
      .replace(/^\uFEFF/, "")
      .replace(/\r\n?/g, "\n")
      .replace(/^WEBVTT[^\n]*\n/i, "");
    const blocks = normalized.split(/\n{2,}/);
    const cues = [];

    for (const block of blocks) {
      const lines = block.split("\n").map((line) => line.trimEnd());
      const timeIndex = lines.findIndex((line) => line.includes("-->"));
      if (timeIndex < 0) continue;

      const match = lines[timeIndex].match(
        /((?:\d{1,2}:)?\d{1,2}:\d{2}[.,]\d{1,3})\s*-->\s*((?:\d{1,2}:)?\d{1,2}:\d{2}[.,]\d{1,3})/
      );
      if (!match) continue;

      const text = cleanCueText(lines.slice(timeIndex + 1).join(" "));
      const start = parseTime(match[1]);
      const end = parseTime(match[2]);
      if (!text || start === null || end === null) continue;
      cues.push({ start, end, text });
    }

    return normalizeCues(cues);
  }

  function parseTtml(input) {
    const cues = [];
    const paragraphPattern = /<p\b([^>]*)>([\s\S]*?)<\/p>/gi;
    let match;
    while ((match = paragraphPattern.exec(String(input || "")))) {
      const attributes = match[1];
      const begin = attributes.match(/\bbegin=["']([^"']+)["']/i)?.[1];
      const endValue = attributes.match(/\bend=["']([^"']+)["']/i)?.[1];
      const duration = attributes.match(/\bdur=["']([^"']+)["']/i)?.[1];
      const start = parseTime(begin);
      const end = parseTime(endValue) ?? (start !== null ? start + (parseTime(duration) || 2) : null);
      const text = cleanCueText(match[2]);
      if (text && start !== null && end !== null) cues.push({ start, end, text });
    }
    return normalizeCues(cues);
  }

  function firstValue(object, keys) {
    for (const key of keys) {
      if (object[key] !== undefined && object[key] !== null) return object[key];
    }
    return null;
  }

  function firstEntry(object, keys) {
    for (const key of keys) {
      if (object[key] !== undefined && object[key] !== null) return { key, value: object[key] };
    }
    return null;
  }

  function parseJsonTime(entry, preferMilliseconds = false) {
    if (!entry) return null;
    const numeric = typeof entry.value === "number" ? entry.value : Number(entry.value);
    const explicitMilliseconds = /ms|millisecond/i.test(entry.key);
    const likelyMilliseconds = /(?:_time|Time)$/i.test(entry.key) && Number.isInteger(numeric);
    if (Number.isFinite(numeric) && (explicitMilliseconds || likelyMilliseconds || preferMilliseconds)) {
      return numeric / 1000;
    }
    return parseTime(entry.value);
  }

  function parseJsonCues(input) {
    let data;
    try {
      data = typeof input === "string" ? JSON.parse(input) : input;
    } catch {
      return [];
    }

    const cues = [];
    const seen = new WeakSet();
    const visit = (value, depth) => {
      if (!value || typeof value !== "object" || depth > 20 || seen.has(value)) return;
      seen.add(value);

      if (!Array.isArray(value)) {
        const text = firstValue(value, ["text", "caption", "content", "utf8", "line"]);
        const startEntry = firstEntry(value, [
          "start",
          "startTime",
          "start_time",
          "startMs",
          "start_ms",
          "from"
        ]);
        const endEntry = firstEntry(value, [
          "end",
          "endTime",
          "end_time",
          "endMs",
          "end_ms",
          "to"
        ]);
        const durationEntry = firstEntry(value, ["duration", "durationMs", "duration_ms"]);
        const startNumeric = Number(startEntry?.value);
        const endNumeric = Number(endEntry?.value);
        const ambiguousMilliseconds =
          ["start", "end"].includes(startEntry?.key) &&
          ["start", "end"].includes(endEntry?.key) &&
          Number.isInteger(startNumeric) &&
          Number.isInteger(endNumeric) &&
          (endNumeric - startNumeric > 30 || endNumeric > 600);
        const start = parseJsonTime(startEntry, ambiguousMilliseconds);
        let end = parseJsonTime(endEntry, ambiguousMilliseconds);
        if (end === null && start !== null) end = start + (parseJsonTime(durationEntry) || 2);
        const normalizedText = typeof text === "string" ? cleanCueText(text) : "";
        if (normalizedText && start !== null && end !== null) {
          cues.push({ start, end, text: normalizedText });
        }
      }

      for (const child of Object.values(value)) visit(child, depth + 1);
    };

    visit(data, 0);
    return normalizeCues(cues);
  }

  function normalizeCues(cues) {
    const sorted = [...cues]
      .filter((cue) => cue.text && Number.isFinite(cue.start) && Number.isFinite(cue.end))
      .sort((left, right) => left.start - right.start || left.end - right.end);
    const result = [];
    const fingerprints = new Set();

    for (const cue of sorted) {
      const fingerprint = `${Math.round(cue.start * 100)}:${Math.round(cue.end * 100)}:${cue.text}`;
      if (fingerprints.has(fingerprint)) continue;
      fingerprints.add(fingerprint);
      result.push({
        start: Math.max(0, cue.start),
        end: Math.max(cue.start, cue.end),
        text: cue.text
      });
    }
    return result;
  }

  function parseSubtitlePayload(input, contentType = "", sourceUrl = "") {
    const text = String(input || "").trim();
    if (!text) return [];
    const hint = `${contentType} ${sourceUrl}`.toLowerCase();

    if (hint.includes("json") || text.startsWith("{") || text.startsWith("[")) {
      const jsonCues = parseJsonCues(text);
      if (jsonCues.length) return jsonCues;
    }
    if (hint.includes("ttml") || hint.includes("xml") || /<(?:tt|transcript)\b/i.test(text)) {
      const ttmlCues = parseTtml(text);
      if (ttmlCues.length) return ttmlCues;
    }
    return parseVttOrSrt(text);
  }

  function formatTimestamp(seconds) {
    const safe = Math.max(0, Number(seconds) || 0);
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const secs = Math.floor(safe % 60);
    return hours
      ? `${hours}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`
      : `${minutes}:${String(secs).padStart(2, "0")}`;
  }

  function formatLanguageLabel(language, languageCode = "") {
    const rawLanguage = String(language || "").trim();
    const normalized = `${languageCode} ${rawLanguage}`.toLowerCase();
    const labels = [
      { pattern: /(^|\s)(es(?:[-_][a-z]{2})?|spa)(\s|$)|spanish|español|espanol|西班牙语/, label: "Español / 西班牙语" },
      { pattern: /(^|\s)(en(?:[-_][a-z]{2})?|eng)(\s|$)|english|英语/, label: "English / 英语" },
      { pattern: /(^|\s)(zh(?:[-_][a-z]{2,4})?|chi|zho)(\s|$)|chinese|中文|汉语/, label: "中文" },
      { pattern: /(^|\s)(pt(?:[-_][a-z]{2})?|por)(\s|$)|portuguese|português|葡萄牙语/, label: "Português / 葡萄牙语" },
      { pattern: /(^|\s)(fr(?:[-_][a-z]{2})?|fra|fre)(\s|$)|french|français|法语/, label: "Français / 法语" }
    ];
    const matched = labels.find((item) => item.pattern.test(normalized));
    return matched?.label || rawLanguage || languageCode || "未知语言";
  }

  function extractVideoId(value) {
    return String(value || "").match(/\/video\/(\d{8,})/)?.[1] || "";
  }

  function firstHttpsUrl(value, depth = 0) {
    if (depth > 8 || value === null || value === undefined) return "";
    if (typeof value === "string") return value.startsWith("https://") ? value : "";
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = firstHttpsUrl(item, depth + 1);
        if (found) return found;
      }
      return "";
    }
    if (typeof value !== "object") return "";
    const preferredKeys = ["Url", "url", "Src", "src", "UrlList", "urlList"];
    for (const key of preferredKeys) {
      if (value[key] === undefined) continue;
      const found = firstHttpsUrl(value[key], depth + 1);
      if (found) return found;
    }
    return "";
  }

  function collectHttpsUrls(value, output, depth = 0) {
    if (depth > 8 || value === null || value === undefined) return;
    if (typeof value === "string") {
      if (value.startsWith("https://")) output.push(value);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((item) => collectHttpsUrls(item, output, depth + 1));
      return;
    }
    if (typeof value !== "object") return;
    ["Url", "url", "Src", "src", "UrlList", "urlList"].forEach((key) => {
      if (value[key] !== undefined) collectHttpsUrls(value[key], output, depth + 1);
    });
  }

  function findTikTokMediaUrls(item) {
    const video = item?.video || item;
    if (!video || typeof video !== "object") return [];
    const urls = [];
    const directCandidates = [
      video.playAddr,
      video.PlayAddr,
      video.downloadAddr,
      video.DownloadAddr
    ];
    directCandidates.forEach((candidate) => collectHttpsUrls(candidate, urls));
    const bitrateEntries = video.bitrateInfo || video.BitrateInfo || [];
    for (const entry of Array.isArray(bitrateEntries) ? bitrateEntries : []) {
      collectHttpsUrls(entry?.PlayAddr || entry?.playAddr || entry, urls);
    }
    const unique = [...new Set(urls)];
    return unique.sort((left, right) => {
      const score = (rawUrl) => {
        try {
          const hostname = new URL(rawUrl).hostname;
          if (hostname === "www.tiktok.com") return 0;
          if (hostname.endsWith(".tiktok.com")) return 1;
          return 2;
        } catch {
          return 3;
        }
      };
      return score(left) - score(right);
    });
  }

  function findTikTokMediaUrl(item) {
    return findTikTokMediaUrls(item)[0] || firstHttpsUrl(item);
  }

  root.SubtitleUtils = {
    cleanCueText,
    extractVideoId,
    findTikTokMediaUrl,
    findTikTokMediaUrls,
    formatLanguageLabel,
    formatTimestamp,
    normalizeCues,
    parseJsonCues,
    parseSubtitlePayload,
    parseTime,
    parseTtml,
    parseVttOrSrt
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = root.SubtitleUtils;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
