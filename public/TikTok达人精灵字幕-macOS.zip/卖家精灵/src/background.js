"use strict";

importScripts("subtitles.js");

const DEFAULT_SETTINGS = {
  autoOpen: true,
  autoTranslate: false,
  panelEnabled: true
};

const CAPTION_HOST_SUFFIXES = [
  ".tiktok.com",
  ".tiktokcdn.com",
  ".tiktokcdn-us.com",
  ".tiktokcdn-eu.com",
  ".tiktokv.com",
  ".byteoversea.com",
  ".ibyteimg.com",
  ".ibytedtos.com"
];
const AUDIO_SERVICE_ORIGIN = "http://127.0.0.1:8765";
const AUDIO_NATIVE_HOST = "com.tiktok_creator_subtitles.audio";

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
    chrome.storage.sync.set(settings);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return false;

  const handlers = {
    FETCH_SUBTITLE: () => fetchSubtitle(message.url),
    TRANSCRIBE_AUDIO: () =>
      transcribeAudio(message.mediaUrls || [message.mediaUrl], message.pageUrl, message.videoId),
    TRANSLATE_CUES: () => translateCues(message.cues)
  };
  const handler = handlers[message.type];
  if (!handler) return false;

  handler()
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

function isAllowedCaptionUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return (
      url.protocol === "https:" &&
      CAPTION_HOST_SUFFIXES.some(
        (suffix) => url.hostname === suffix.slice(1) || url.hostname.endsWith(suffix)
      )
    );
  } catch {
    return false;
  }
}

async function fetchSubtitle(url) {
  if (!isAllowedCaptionUrl(url)) throw new Error("字幕地址不在允许的 TikTok 域名内");

  const response = await fetch(url, {
    cache: "no-store",
    credentials: "omit",
    redirect: "follow"
  });
  if (!response.ok) throw new Error(`字幕请求失败 (HTTP ${response.status})`);

  const text = await response.text();
  const contentType = response.headers.get("content-type") || "";
  const cues = SubtitleUtils.parseSubtitlePayload(text, contentType, url);
  if (!cues.length) throw new Error("已读取字幕文件，但未识别出有效字幕");
  return { cues, contentType };
}

async function transcribeAudio(rawMediaUrls, pageUrl, videoId) {
  await ensureAudioService();
  let cachedResponse;
  try {
    cachedResponse = await fetch(`${AUDIO_SERVICE_ORIGIN}/transcript/${encodeURIComponent(videoId)}`, {
      cache: "no-store"
    });
  } catch {
    throw new Error("音轨服务启动后仍无法连接，请重新安装本机组件");
  }
  if (cachedResponse.ok) {
    const cachedPayload = await cachedResponse.json();
    return translateLocalTranscript(cachedPayload, videoId);
  }
  if (cachedResponse.status !== 404) {
    throw new Error(`本地 Whisper 缓存查询失败 (HTTP ${cachedResponse.status})`);
  }

  const mediaUrls = [...new Set((Array.isArray(rawMediaUrls) ? rawMediaUrls : []).filter(Boolean))].slice(0, 16);
  let mediaResponse = null;
  let lastStatus = "";
  for (const mediaUrl of mediaUrls) {
    try {
      const candidate = await fetch(mediaUrl, {
        cache: "no-store",
        credentials: "include",
        headers: { Range: "bytes=0-" },
        redirect: "follow",
        referrer: pageUrl,
        referrerPolicy: "strict-origin-when-cross-origin"
      });
      lastStatus = String(candidate.status);
      if (candidate.ok) {
        mediaResponse = candidate;
        break;
      }
    } catch {
      lastStatus = "network";
    }
  }
  if (!mediaResponse) {
    throw new Error(`当前 Chrome 会话无法读取这条 TikTok 视频媒体 (${lastStatus || "no source"})`);
  }
  const mediaBytes = await mediaResponse.arrayBuffer();
  if (!mediaBytes.byteLength) throw new Error("当前 TikTok 视频媒体为空");
  if (mediaBytes.byteLength > 150 * 1024 * 1024) throw new Error("当前视频超过 150MB 音轨提取限制");

  let response;
  try {
    response = await fetch(`${AUDIO_SERVICE_ORIGIN}/transcribe-upload`, {
      method: "POST",
      cache: "no-store",
      headers: {
        "Content-Type": "application/octet-stream",
        "X-Page-Url": pageUrl,
        "X-Video-Id": videoId
      },
      body: mediaBytes
    });
  } catch {
    throw new Error("音轨服务连接中断，请再次点击刷新");
  }

  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error(`本地 Whisper 服务返回异常 (HTTP ${response.status})`);
  }
  if (!response.ok || !payload?.ok) {
    throw new Error(payload?.error || `本地音轨识别失败 (HTTP ${response.status})`);
  }
  return translateLocalTranscript(payload, videoId);
}

async function ensureAudioService() {
  if (await audioServiceIsHealthy()) return;

  let result;
  try {
    result = await sendNativeMessage({ type: "START_AUDIO_SERVICE" });
  } catch {
    throw new Error("未安装音轨本机组件，请先运行一次“安装插件与音轨服务.command”");
  }
  if (!result?.ok) {
    throw new Error(result?.error || "音轨服务无法自动启动");
  }

  for (let attempt = 0; attempt < 30; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 250));
    if (await audioServiceIsHealthy()) return;
  }
  throw new Error("音轨服务启动超时，请再次点击刷新");
}

async function audioServiceIsHealthy() {
  try {
    const response = await fetch(`${AUDIO_SERVICE_ORIGIN}/health`, {
      cache: "no-store",
      signal: AbortSignal.timeout(1200)
    });
    return response.ok;
  } catch {
    return false;
  }
}

function sendNativeMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(AUDIO_NATIVE_HOST, message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}

async function translateLocalTranscript(payload, videoId) {
  const cues = Array.isArray(payload.cues) ? payload.cues : [];
  if (!cues.length) throw new Error("本地 Whisper 未返回可用文字");

  const translation = await translateCues(cues);
  return {
    cached: Boolean(payload.cached),
    cues,
    language: payload.language || "auto",
    model: payload.model || "Whisper",
    videoId: payload.videoId || videoId,
    ...translation
  };
}

function createBatches(cues, maxCharacters = 2800, maxItems = 24) {
  const batches = [];
  let current = [];
  let size = 0;

  cues.forEach((cue, index) => {
    const text = String(cue.text || "").trim();
    if (!text) return;
    if (current.length && (size + text.length > maxCharacters || current.length >= maxItems)) {
      batches.push(current);
      current = [];
      size = 0;
    }
    current.push({ index, text });
    size += text.length;
  });
  if (current.length) batches.push(current);
  return batches;
}

async function requestGoogleTranslation(text) {
  const endpoint = new URL("https://translate.googleapis.com/translate_a/single");
  endpoint.searchParams.set("client", "gtx");
  endpoint.searchParams.set("sl", "auto");
  endpoint.searchParams.set("tl", "zh-CN");
  endpoint.searchParams.set("dt", "t");
  endpoint.searchParams.set("q", text);

  const response = await fetch(endpoint, { cache: "no-store", credentials: "omit" });
  if (!response.ok) throw new Error(`翻译服务返回 HTTP ${response.status}`);
  const payload = await response.json();
  const translated = Array.isArray(payload?.[0])
    ? payload[0].map((segment) => segment?.[0] || "").join("")
    : "";
  if (!translated.trim()) throw new Error("翻译服务未返回内容");
  return translated.trim();
}

async function translateBatch(batch) {
  const separator = "TTDARENSPLIT8675309";
  const combined = batch.map((item) => item.text).join(`\n${separator}\n`);
  const translated = await requestGoogleTranslation(combined);
  const parts = translated.split(new RegExp(`\\s*${separator}\\s*`, "i"));
  if (parts.length !== batch.length) throw new Error("翻译结果无法与字幕对齐");
  return parts.map((text, offset) => ({ index: batch[offset].index, text: text.trim() }));
}

async function translateIndividually(batch) {
  const completed = [];
  let cursor = 0;
  const workers = Array.from({ length: Math.min(4, batch.length) }, async () => {
    while (cursor < batch.length) {
      const item = batch[cursor];
      cursor += 1;
      try {
        const translated = await requestGoogleTranslation(item.text);
        completed.push({ index: item.index, text: translated, ok: true });
      } catch {
        completed.push({ index: item.index, text: item.text, ok: false });
      }
    }
  });
  await Promise.all(workers);
  return completed;
}

async function translateCues(rawCues) {
  const cues = Array.isArray(rawCues) ? rawCues.slice(0, 500) : [];
  if (!cues.length) throw new Error("没有可翻译的字幕");

  const translations = cues.map((cue) => String(cue.text || ""));
  const batches = createBatches(cues);
  let failed = 0;

  for (const batch of batches) {
    try {
      const result = await translateBatch(batch);
      result.forEach((item) => {
        translations[item.index] = item.text || cues[item.index].text;
      });
    } catch {
      const result = await translateIndividually(batch);
      result.forEach((item) => {
        translations[item.index] = item.text || cues[item.index].text;
        if (!item.ok) failed += 1;
      });
    }
  }

  return {
    translations,
    failed,
    translated: cues.length - failed,
    total: cues.length
  };
}
