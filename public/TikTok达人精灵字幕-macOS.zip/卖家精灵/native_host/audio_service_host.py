#!/usr/bin/env python3
"""Native Messaging bridge that starts the local audio service on demand."""

from __future__ import annotations

import json
import os
import struct
import subprocess
import sys
from pathlib import Path
from urllib.request import urlopen


ROOT = Path(__file__).resolve().parent.parent
PYTHON = ROOT / ".runtime" / "venv" / "bin" / "python"
SERVER = ROOT / "local_service" / "server.py"
LOG = ROOT / "local_service" / "audio_service.log"


def read_message() -> dict:
    header = sys.stdin.buffer.read(4)
    if len(header) != 4:
        return {}
    length = struct.unpack("=I", header)[0]
    if length <= 0 or length > 1024 * 1024:
        raise ValueError("本机消息长度无效")
    body = sys.stdin.buffer.read(length)
    if len(body) != length:
        raise ValueError("本机消息不完整")
    return json.loads(body.decode("utf-8"))


def send_message(payload: dict) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("=I", len(body)))
    sys.stdout.buffer.write(body)
    sys.stdout.buffer.flush()


def service_is_healthy() -> bool:
    try:
        with urlopen("http://127.0.0.1:8765/health", timeout=1) as response:
            return response.status == 200
    except OSError:
        return False


def start_service() -> dict:
    if service_is_healthy():
        return {"ok": True, "alreadyRunning": True}
    if not PYTHON.is_file():
        return {"ok": False, "error": "音轨组件尚未安装，请重新运行安装程序"}
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("ab") as log:
        subprocess.Popen(
            [str(PYTHON), str(SERVER)],
            cwd=str(ROOT),
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=log,
            start_new_session=True,
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
    return {"ok": True, "started": True}


def main() -> None:
    try:
        message = read_message()
        if message.get("type") != "START_AUDIO_SERVICE":
            send_message({"ok": False, "error": "不支持的本机消息"})
            return
        send_message(start_service())
    except Exception as error:
        send_message({"ok": False, "error": f"音轨服务启动失败：{error}"})


if __name__ == "__main__":
    main()
