#!/usr/bin/env python3
"""Local-only TikTok audio extraction and Whisper transcription service."""

from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import imageio_ffmpeg
import requests
from pywhispercpp.model import Model


HOST = "127.0.0.1"
PORT = int(os.environ.get("TTDS_AUDIO_PORT", "8765"))
MODEL_NAME = os.environ.get("TTDS_WHISPER_MODEL", "base")
ROOT = Path(__file__).resolve().parent
MODELS_DIR = ROOT / "models"
CACHE_DIR = ROOT / "cache"
MAX_MEDIA_BYTES = 150 * 1024 * 1024
MAX_DURATION_SECONDS = 10 * 60
TRUSTED_HOST_SUFFIXES = (
    ".tiktok.com",
    ".tiktokcdn.com",
    ".tiktokcdn-us.com",
    ".tiktokcdn-eu.com",
    ".tiktokv.com",
    ".byteoversea.com",
    ".ibyteimg.com",
    ".ibytedtos.com",
)

_model: Model | None = None
_model_lock = threading.Lock()
_transcription_lock = threading.Lock()


def json_bytes(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def is_trusted_media_url(raw_url: str) -> bool:
    try:
        parsed = urlparse(raw_url)
    except ValueError:
        return False
    hostname = (parsed.hostname or "").lower()
    return parsed.scheme == "https" and any(
        hostname == suffix[1:] or hostname.endswith(suffix) for suffix in TRUSTED_HOST_SUFFIXES
    )


def get_model() -> Model:
    global _model
    if _model is not None:
        return _model
    with _model_lock:
        if _model is None:
            MODELS_DIR.mkdir(parents=True, exist_ok=True)
            _model = Model(
                MODEL_NAME,
                models_dir=str(MODELS_DIR),
                language="auto",
                print_progress=False,
                print_realtime=False,
                print_timestamps=False,
            )
    return _model


def download_media(media_url: str, page_url: str, destination: Path) -> None:
    headers = {
        "Accept": "video/*,audio/*;q=0.9,*/*;q=0.5",
        "Referer": page_url,
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36"
        ),
    }
    with requests.get(media_url, headers=headers, stream=True, timeout=(15, 90)) as response:
        response.raise_for_status()
        declared_size = int(response.headers.get("content-length") or 0)
        if declared_size > MAX_MEDIA_BYTES:
            raise ValueError("视频文件超过 150MB 限制")
        size = 0
        with destination.open("wb") as output:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if not chunk:
                    continue
                size += len(chunk)
                if size > MAX_MEDIA_BYTES:
                    raise ValueError("视频文件超过 150MB 限制")
                output.write(chunk)
    if not destination.exists() or destination.stat().st_size == 0:
        raise ValueError("下载的视频文件为空")


def extract_audio(media_path: Path, audio_path: Path) -> None:
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    command = [
        ffmpeg,
        "-nostdin",
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-i",
        str(media_path),
        "-t",
        str(MAX_DURATION_SECONDS),
        "-vn",
        "-ac",
        "1",
        "-ar",
        "16000",
        "-acodec",
        "pcm_s16le",
        str(audio_path),
    ]
    completed = subprocess.run(command, capture_output=True, text=True, timeout=180, check=False)
    if completed.returncode != 0 or not audio_path.exists() or audio_path.stat().st_size < 1000:
        detail = completed.stderr.strip().splitlines()[-1] if completed.stderr.strip() else "未识别到音频流"
        raise ValueError(f"音轨提取失败：{detail}")


def segments_to_cues(segments) -> list[dict]:
    cues = []
    for segment in segments:
        text = str(segment.text or "").strip()
        if not text:
            continue
        cues.append(
            {
                "start": max(0, float(segment.t0) / 100),
                "end": max(float(segment.t0), float(segment.t1)) / 100,
                "text": text,
            }
        )
    return cues


def looks_spanish(cues: list[dict]) -> bool:
    text = " ".join(str(cue.get("text") or "") for cue in cues).lower()
    words = set(re.findall(r"[a-záéíóúñü]+", text))
    markers = {
        "antes",
        "baño",
        "como",
        "con",
        "cuando",
        "esta",
        "esto",
        "hacer",
        "para",
        "pero",
        "porque",
        "que",
        "tenía",
        "todo",
        "una",
        "voy",
    }
    return len(words & markers) >= 4


def transcribe_audio(audio_path: Path) -> tuple[list[dict], str]:
    model = get_model()
    segments = model.transcribe(
        str(audio_path),
        language="auto",
        translate=False,
        print_progress=False,
        print_realtime=False,
        print_timestamps=False,
        suppress_blank=True,
    )
    cues = segments_to_cues(segments)
    language = "auto"
    if looks_spanish(cues):
        cues = segments_to_cues(
            model.transcribe(
                str(audio_path),
                language="es",
                translate=False,
                print_progress=False,
                print_realtime=False,
                print_timestamps=False,
                suppress_blank=True,
            )
        )
        language = "es"
    if not cues:
        raise ValueError("音轨已提取，但未识别到可用语音")
    return cues, language


def cache_path(video_id: str) -> Path:
    safe_id = re.sub(r"[^0-9]", "", video_id)
    if not safe_id:
        raise ValueError("缺少有效的 TikTok 视频 ID")
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return CACHE_DIR / f"{safe_id}.json"


def transcribe_media_path(media_path: Path, video_id: str) -> dict:
    target_cache = cache_path(video_id)
    if target_cache.exists():
        cached = json.loads(target_cache.read_text(encoding="utf-8"))
        return {**cached, "cached": True}

    audio_path = media_path.with_suffix(".wav")
    extract_audio(media_path, audio_path)
    cues, language = transcribe_audio(audio_path)
    result = {
        "videoId": video_id,
        "model": MODEL_NAME,
        "language": language,
        "cues": cues,
        "cached": False,
    }
    target_cache.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    return result


def process_transcription(media_url: str, page_url: str, video_id: str) -> dict:
    target_cache = cache_path(video_id)
    if target_cache.exists():
        cached = json.loads(target_cache.read_text(encoding="utf-8"))
        return {**cached, "cached": True}
    with _transcription_lock:
        if target_cache.exists():
            cached = json.loads(target_cache.read_text(encoding="utf-8"))
            return {**cached, "cached": True}
        with tempfile.TemporaryDirectory(prefix="ttds-audio-") as temp_dir:
            media_path = Path(temp_dir) / "video.mp4"
            download_media(media_url, page_url, media_path)
            return transcribe_media_path(media_path, video_id)


def process_uploaded_media(stream, content_length: int, video_id: str) -> dict:
    target_cache = cache_path(video_id)
    if target_cache.exists():
        cached = json.loads(target_cache.read_text(encoding="utf-8"))
        return {**cached, "cached": True}
    if content_length <= 0 or content_length > MAX_MEDIA_BYTES:
        raise ValueError("视频文件超过 150MB 限制或长度无效")
    with _transcription_lock:
        if target_cache.exists():
            cached = json.loads(target_cache.read_text(encoding="utf-8"))
            return {**cached, "cached": True}
        with tempfile.TemporaryDirectory(prefix="ttds-upload-") as temp_dir:
            media_path = Path(temp_dir) / "video.mp4"
            remaining = content_length
            with media_path.open("wb") as output:
                while remaining:
                    chunk = stream.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ValueError("视频文件上传不完整")
                    output.write(chunk)
                    remaining -= len(chunk)
            return transcribe_media_path(media_path, video_id)


class Handler(BaseHTTPRequestHandler):
    server_version = "TikTokSubtitleAudio/0.1"

    def log_message(self, format_string: str, *args) -> None:
        print(f"[{self.log_date_time_string()}] {format_string % args}", flush=True)

    def allowed_origin(self) -> str | None:
        origin = self.headers.get("Origin")
        if not origin:
            return None
        if origin.startswith("chrome-extension://") or origin.startswith("extension://"):
            return origin
        return ""

    def send_json(self, status: int, payload: dict) -> None:
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        origin = self.allowed_origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        if self.allowed_origin() == "":
            self.send_json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "不允许的请求来源"})
            return
        self.send_response(HTTPStatus.NO_CONTENT)
        origin = self.allowed_origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Video-Id, X-Page-Url")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        if self.path.startswith("/transcript/"):
            video_id = self.path.removeprefix("/transcript/")
            try:
                target_cache = cache_path(video_id)
            except ValueError as error:
                self.send_json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(error)})
                return
            if not target_cache.exists():
                self.send_json(HTTPStatus.NOT_FOUND, {"ok": False, "missing": True})
                return
            cached = json.loads(target_cache.read_text(encoding="utf-8"))
            self.send_json(HTTPStatus.OK, {"ok": True, **cached, "cached": True})
            return
        if self.path != "/health":
            self.send_json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not found"})
            return
        self.send_json(
            HTTPStatus.OK,
            {
                "ok": True,
                "model": MODEL_NAME,
                "modelLoaded": _model is not None,
                "service": "TikTok local audio transcription",
            },
        )

    def do_POST(self) -> None:
        if self.path not in ("/transcribe", "/transcribe-upload"):
            self.send_json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not found"})
            return
        if self.allowed_origin() == "":
            self.send_json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "不允许的请求来源"})
            return
        try:
            if self.path == "/transcribe-upload":
                content_length = int(self.headers.get("Content-Length") or 0)
                page_url = str(self.headers.get("X-Page-Url") or "")
                video_id = str(self.headers.get("X-Video-Id") or "")
                if not page_url.startswith("https://www.tiktok.com/"):
                    raise ValueError("视频页地址无效")
                result = process_uploaded_media(self.rfile, content_length, video_id)
                self.send_json(HTTPStatus.OK, {"ok": True, **result})
                return

            content_length = int(self.headers.get("Content-Length") or 0)
            if content_length <= 0 or content_length > 64 * 1024:
                raise ValueError("请求内容长度无效")
            payload = json.loads(self.rfile.read(content_length))
            media_url = str(payload.get("mediaUrl") or "")
            page_url = str(payload.get("pageUrl") or "")
            video_id = str(payload.get("videoId") or "")
            if not is_trusted_media_url(media_url):
                raise ValueError("音频地址不在允许的 TikTok 域名内")
            if not page_url.startswith("https://www.tiktok.com/"):
                raise ValueError("视频页地址无效")
            result = process_transcription(media_url, page_url, video_id)
            self.send_json(HTTPStatus.OK, {"ok": True, **result})
        except requests.RequestException as error:
            self.send_json(HTTPStatus.BAD_GATEWAY, {"ok": False, "error": f"视频下载失败：{error}"})
        except (ValueError, json.JSONDecodeError) as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(error)})
        except subprocess.TimeoutExpired:
            self.send_json(HTTPStatus.REQUEST_TIMEOUT, {"ok": False, "error": "音轨提取超时"})
        except Exception as error:
            self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"ok": False, "error": f"本地识别失败：{error}"})


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"TikTok audio service listening on http://{HOST}:{PORT}", flush=True)
    print(f"Whisper model: {MODEL_NAME} (downloads on first transcription)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
