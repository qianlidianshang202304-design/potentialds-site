"use strict";

const DEFAULT_SETTINGS = {
  autoOpen: true,
  autoTranslate: false,
  panelEnabled: true
};

const controls = Object.fromEntries(
  Object.keys(DEFAULT_SETTINGS).map((key) => [key, document.getElementById(key)])
);
const pageStatus = document.getElementById("pageStatus");
const openPanel = document.getElementById("openPanel");
const feedback = document.getElementById("feedback");

chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
  Object.entries(controls).forEach(([key, control]) => {
    control.checked = Boolean(settings[key]);
    control.addEventListener("change", () => {
      chrome.storage.sync.set({ [key]: control.checked });
    });
  });
});

chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  const isTikTok = /^https:\/\/([^.]+\.)*tiktok\.com\//i.test(tab?.url || "");
  pageStatus.textContent = isTikTok ? "当前页面可读取字幕" : "请先打开 TikTok 视频页";
  openPanel.disabled = !isTikTok;
  openPanel.dataset.tabId = isTikTok ? String(tab.id) : "";
});

openPanel.addEventListener("click", () => {
  const tabId = Number(openPanel.dataset.tabId);
  if (!tabId) return;
  controls.panelEnabled.checked = true;
  chrome.storage.sync.set({ panelEnabled: true }, () => {
    chrome.tabs.sendMessage(tabId, { type: "OPEN_PANEL" }, (response) => {
      if (chrome.runtime.lastError || !response?.ok) {
        feedback.textContent = "请刷新 TikTok 页面后再试";
        return;
      }
      window.close();
    });
  });
});
