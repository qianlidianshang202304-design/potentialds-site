#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PYTHON="$PROJECT_DIR/.runtime/venv/bin/python"

if [ ! -x "$PYTHON" ]; then
  echo "Run scripts/setup_audio_service.sh first." >&2
  exit 1
fi

exec "$PYTHON" "$PROJECT_DIR/local_service/server.py"
