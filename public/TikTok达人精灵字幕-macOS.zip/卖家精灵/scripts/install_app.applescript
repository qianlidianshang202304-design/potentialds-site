on run
  set appPath to POSIX path of (path to me)
  set bundlePath to do shell script "/usr/bin/dirname " & quoted form of appPath
  set projectPath to do shell script "/usr/bin/dirname " & quoted form of bundlePath
  set installerPath to projectPath & "/scripts/install_all.sh"

  tell application "Terminal"
    activate
    do script "/bin/bash " & quoted form of installerPath
  end tell
end run
