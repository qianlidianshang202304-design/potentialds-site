#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
HOST_SCRIPT="$PROJECT_DIR/native_host/audio_service_host.py"
HOST_NAME="com.tiktok_creator_subtitles.audio"
EXTENSION_ID="dgdndppfgcpplkofbchlmeabnhbfjnfe"

chmod +x "$HOST_SCRIPT"

install_manifest() {
  local browser_dir="$1"
  mkdir -p "$browser_dir"
  python3 - "$browser_dir/$HOST_NAME.json" "$HOST_SCRIPT" "$HOST_NAME" "$EXTENSION_ID" <<'PY'
import json
import sys
from pathlib import Path

destination, host_script, host_name, extension_id = sys.argv[1:]
payload = {
    "name": host_name,
    "description": "TikTok subtitle local audio service launcher",
    "path": host_script,
    "type": "stdio",
    "allowed_origins": [f"chrome-extension://{extension_id}/"],
}
Path(destination).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
PY
}

install_manifest "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
install_manifest "$HOME/Library/Application Support/Microsoft Edge/NativeMessagingHosts"

echo "本机组件安装完成。扩展 ID: $EXTENSION_ID"
