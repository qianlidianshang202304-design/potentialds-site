#!/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

show_error() {
  local exit_code=$?
  echo
  echo "安装没有完成，请把此窗口中的错误信息发给插件提供者。"
  read -r -p "按回车键关闭此窗口。"
  exit "$exit_code"
}
trap show_error ERR

echo "正在安装本地 Whisper 依赖，请保持网络连接……"
"$PROJECT_DIR/scripts/setup_audio_service.sh"
"$PROJECT_DIR/scripts/install_native_host.sh"

echo
echo "安装完成。"
echo "现在请在 Chrome 扩展页面加载或重新加载此文件夹。"
echo "以后只需点击字幕面板的刷新按钮，音轨服务会自动在后台启动。"
echo
trap - ERR
read -r -p "按回车键关闭此窗口。"
