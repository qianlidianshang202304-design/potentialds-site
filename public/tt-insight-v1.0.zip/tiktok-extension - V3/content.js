// content.js - 自动分批导入版 (解决 413/500 报错)

// ⚠️ 替换您的 Supabase 配置
const SUPABASE_URL = "https://vlskkxzfdjgoazrkzqtx.supabase.co"; 
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZsc2treHpmZGpnb2F6cmt6cXR4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU4NTk1NTQsImV4cCI6MjA4MTQzNTU1NH0.294aAiIVpCBvj3Of0FwfXFMHazFqluAnck0QphvJZ2A"; 
const SERVER_URL = "https://tiktokusapi.onrender.com";

// 配置
const EXCLUDE_EMAILS = ["example@example.com", "email@email.com", "support@tiktok.com", "leah@krugercowne.com"]; 
const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;

// 🟢 每次只传 200 条，绝对不会报错
const BATCH_SIZE = 200; 

let g_user = { id: '', email: '', token: '' };

// ==========================================
// 1. 初始化
// ==========================================
function initAuth() {
    if (!window.location.hostname.includes('tiktok.com')) return;
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;

    chrome.storage.local.get(['user_id', 'user_email', 'access_token'], (res) => {
        if (res.user_id) {
            console.log("[LeadTracking] 身份验证通过:", res.user_email);
            g_user = { id: res.user_id, email: res.user_email, token: res.access_token };
            initMain(); 
        } else {
            console.log("[LeadTracking] 未登录，准备显示登录板");
            setTimeout(() => { showLoginPanel(); }, 1000);
        }
    });
}

function initMain() {
    if (!g_user.id) return;
    const handle = window.location.pathname.split('/')[1];
    if (handle && handle.startsWith('@')) {
        setTimeout(async () => {
            const metaData = getTikTokMetaData(); 
            const uid = metaData.uid;
            if (uid) {
                let scrapedEmail = metaData.signatureEmail || findEmailInBody();
                fetchDataAndUpsert(uid, handle, scrapedEmail, metaData);
            } else {
                showDataPanel({ found: false }, handle, "UID获取失败");
            }
        }, 2000);
    }
}

// ==========================================
// 2. 导入功能 (核心修改：分批上传)
// ==========================================
function showImportModal() {
    const existing = document.getElementById('gmv-auth-modal');
    if (existing) existing.remove();
    const modal = document.createElement('div');
    modal.id = 'gmv-auth-modal';
    modal.innerHTML = `
        <div class="auth-box">
            <div class="auth-close">×</div>
            <div class="auth-title">导入数据 (自动分批)</div>
            <textarea id="paste-area" class="paste-input" placeholder="请粘贴 Excel 内容 (Handle 和 BD 两列)"></textarea>
            <input id="col-name" class="auth-input" placeholder="集合名称 (例如: 1月名单)">
            <button id="do-paste-import" class="auth-btn">开始导入</button>
            <div id="auth-msg" style="margin-top:8px;font-size:12px;white-space:pre-wrap;"></div>
        </div>`;
    document.body.appendChild(modal);
    
    // 关闭按钮
    modal.querySelector('.auth-close').onclick = () => modal.remove();

    // 导入按钮点击事件
    document.getElementById('do-paste-import').onclick = async () => {
        const rawText = document.getElementById('paste-area').value.trim();
        const colName = document.getElementById('col-name').value;
        const msg = document.getElementById('auth-msg');
        
        if(!rawText) return msg.innerText = "❌ 请先粘贴内容";
        
        // 1. 解析数据
        msg.innerText = "正在解析数据...";
        const rows = rawText.split('\n');
        const items = rows.map(row => {
            let cols = row.trim().split(/\t+/); // 优先按 Tab 分割 (Excel默认)
            if(cols.length < 2) cols = row.trim().split(/\s+/); // 其次按空格
            return (cols.length >= 2) ? { handle: cols[0].replace('@','').trim(), bd_name: cols[1].trim() } : null;
        }).filter(i => i && i.handle && i.bd_name);

        const total = items.length;
        if(total === 0) return msg.innerText = "❌ 未识别到有效数据，请检查格式";

        msg.style.color = "#333";
        msg.innerText = `🔍 识别到 ${total} 条数据，准备分批上传...`;

        // 2. 分批上传逻辑 (Batch Processing)
        let successCount = 0;
        let failCount = 0;
        
        // 锁定按钮防止重复点击
        document.getElementById('do-paste-import').disabled = true;
        document.getElementById('do-paste-import').style.background = "#ccc";

        // 计算批次
        const batches = [];
        for (let i = 0; i < total; i += BATCH_SIZE) {
            batches.push(items.slice(i, i + BATCH_SIZE));
        }

        const finalCollectionName = colName || `分批导入_${new Date().toISOString().split('T')[0]}`;

        try {
            for (let i = 0; i < batches.length; i++) {
                const batch = batches[i];
                const currentBatchNum = i + 1;
                
                msg.innerText = `🚀 正在上传第 ${currentBatchNum}/${batches.length} 批 (${batch.length}条)...`;

                // 发送请求
                const res = await fetch(`${SERVER_URL}/api/import-json`, {
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        userId: g_user.id, 
                        collectionName: finalCollectionName, 
                        items: batch 
                    })
                });

                if (res.ok) {
                    successCount += batch.length;
                } else {
                    failCount += batch.length;
                    console.error(`Batch ${currentBatchNum} failed:`, await res.text());
                }
            }

            // 3. 最终结果
            msg.style.color = "green";
            msg.innerText = `✅ 导入完成！\n成功: ${successCount} 条\n失败: ${failCount} 条`;
            
            // 如果全部成功，2秒后自动关闭
            if(failCount === 0) {
                setTimeout(() => modal.remove(), 2000);
            }

        } catch (e) {
            msg.style.color = "red";
            msg.innerText = "❌ 网络错误: " + e.message;
        } finally {
            // 恢复按钮
            document.getElementById('do-paste-import').disabled = false;
            document.getElementById('do-paste-import').style.background = "#fe2c55";
        }
    };
}

// ==========================================
// 3. UI 渲染：纯登录面板
// ==========================================
function showLoginPanel() {
    const existing = document.getElementById('gmv-panel');
    if (existing) existing.remove();

    const div = document.createElement('div');
    div.id = 'gmv-panel';
    if (localStorage.getItem('gmvPanelMinimized') === 'true') div.classList.add('minimized');

    const innerContent = `
        <div class="full-content">
            <div class="gmv-header">
                <div class="header-left" style="font-weight:bold; color:#333;">🔒 请先登录插件</div>
                <div id="minimize-btn" class="minimize-btn">−</div>
            </div>
            <div style="padding: 15px 5px;">
                <input id="mini-email" type="text" placeholder="邮箱" style="width:100%; box-sizing:border-box; margin-bottom:8px; padding:8px; border:1px solid #ddd; border-radius:4px; font-size:12px;">
                <input id="mini-pass" type="password" placeholder="密码" style="width:100%; box-sizing:border-box; margin-bottom:12px; padding:8px; border:1px solid #ddd; border-radius:4px; font-size:12px;">
                <button id="mini-login-btn" style="width:100%; background:#fe2c55; color:white; border:none; padding:8px; border-radius:4px; cursor:pointer; font-weight:bold;">登录</button>
                <div id="mini-msg" style="color:red; font-size:11px; margin-top:8px; text-align:center;"></div>
            </div>
            <div class="gmv-footer" style="text-align:center; color:#ccc;">LeadHunter Security</div>
        </div>
    `;

    div.innerHTML = `<div class="mini-icon">🔒</div>${innerContent}`;
    document.body.appendChild(div);

    // 事件绑定
    div.querySelector('#minimize-btn').addEventListener('click', (e) => { e.stopPropagation(); div.classList.add('minimized'); localStorage.setItem('gmvPanelMinimized', 'true'); });
    div.addEventListener('click', () => { 
        if(div.classList.contains('minimized')) { div.classList.remove('minimized'); localStorage.setItem('gmvPanelMinimized', 'false'); }
    });
    
    // 阻止输入框冒泡
    div.querySelector('#mini-email').addEventListener('click', (e) => e.stopPropagation());
    div.querySelector('#mini-pass').addEventListener('click', (e) => e.stopPropagation());

    // 登录
    div.querySelector('#mini-login-btn').addEventListener('click', async (e) => {
        e.stopPropagation();
        const email = document.getElementById('mini-email').value;
        const password = document.getElementById('mini-pass').value;
        const msg = document.getElementById('mini-msg');

        if(!email || !password) { msg.innerText = "请输入账号和密码"; return; }
        msg.innerText = "正在验证...";

        try {
            const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_KEY },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();
            
            if(data.error) throw new Error("账号或密码错误");
            
            msg.style.color = "green";
            msg.innerText = "登录成功!";
            
            chrome.storage.local.set({ 
                user_id: data.user.id, 
                user_email: data.user.email, 
                access_token: data.access_token 
            }, () => {
                setTimeout(() => location.reload(), 800);
            });

        } catch(err) {
            msg.style.color = "red";
            msg.innerText = err.message;
        }
    });
}

// ==========================================
// 4. UI 渲染：数据显示面板
// ==========================================
function showDataPanel(data, handle, uid) {
    const existing = document.getElementById('gmv-panel');
    if (existing) existing.remove();

    const div = document.createElement('div');
    div.id = 'gmv-panel';
    if (localStorage.getItem('gmvPanelMinimized') === 'true') div.classList.add('minimized');

    // 数据格式化
    const rawGmv = data.gmv || data['30天总GMV'];
    const gmvDisplay = rawGmv ? parseFloat(rawGmv).toLocaleString() : '0';
    const rawRatio = data.ratio || data['主要占比'];
    const ratioDisplay = rawRatio ? (parseFloat(rawRatio) * 100).toFixed(1) + '%' : 'N/A';
    const ageDisplay = data.age || data['主要年龄层'] || '-';
    const male = data.male || data['男性'] || 0;
    const female = data.female || data['女性'] || 0;
    const maleDisplay = male > 0 ? (parseFloat(male)*100).toFixed(1)+'%' : '-';
    const femaleDisplay = female > 0 ? (parseFloat(female)*100).toFixed(1)+'%' : '-';
    const bdDisplay = data.bd_manager || '未分配';
    const contactDisplay = data.contact || '暂无';

    const logoutHtml = `<span id="btn-logout" class="login-trigger" style="color:#999; cursor:pointer; border-bottom:1px dashed #ccc;" title="${g_user.email}">👤 退出</span>`;
    const importActionHtml = `<div class="action-row" style="margin-top:6px; padding-top:6px; border-top:1px dashed #eee; text-align:center;"><span id="btn-import-trigger" class="import-trigger" style="font-size:11px; color:#666; cursor:pointer;">📂 导入数据</span></div>`;

    let innerContent = '';
    if (data.found || (contactDisplay !== '暂无')) {
        innerContent = `
            <div class="full-content">
                <div class="gmv-header">
                    <div class="header-left"><div class="status-badge success">✅ 已匹配</div>${logoutHtml}</div>
                    <div id="minimize-btn" class="minimize-btn">−</div>
                </div>
                <div class="gmv-hero"><div class="hero-label">30天预估 GMV</div><div class="hero-value">$${gmvDisplay}</div></div>
                <div class="gmv-grid">
                    <div class="grid-item"><span class="label">年龄</span><span class="value">${ageDisplay}</span></div>
                    <div class="grid-item"><span class="label">占比</span><span class="value highlight">${ratioDisplay}</span></div>
                    <div class="grid-item"><span class="label">男性</span><span class="value" style="color:#0d9488;">${maleDisplay}</span></div>
                    <div class="grid-item"><span class="label">女性</span><span class="value" style="color:#e11d48;">${femaleDisplay}</span></div>
                </div>
                <div class="bd-box"><span class="bd-label">负责 BD</span><span class="bd-value">${bdDisplay}</span></div>
                <div class="gmv-contact"><div class="label">对接邮箱</div><div class="email-text">${contactDisplay}</div></div>
                ${importActionHtml}
                <div class="gmv-footer">UID: ${uid}</div>
            </div>`;
    } else {
        innerContent = `
            <div class="full-content">
                 <div class="gmv-header">
                    <div class="header-left"><div class="status-badge error">❌ 未收录</div>${logoutHtml}</div>
                    <div id="minimize-btn" class="minimize-btn">−</div>
                </div>
                <div class="empty-state">
                    <div class="not-found-text">暂无数据</div>
                    ${contactDisplay !== '暂无' ? `<div class="email-text" style="margin-top:5px">发现邮箱: ${contactDisplay}</div>` : ''}
                    <div class="uid-text">UID: ${uid}</div>
                    ${importActionHtml}
                </div>
            </div>`;
    }

    div.innerHTML = `<div class="mini-icon">查</div>${innerContent}`;
    document.body.appendChild(div);

    // 事件
    div.querySelector('#minimize-btn').addEventListener('click', (e) => { e.stopPropagation(); div.classList.add('minimized'); localStorage.setItem('gmvPanelMinimized', 'true'); });
    div.addEventListener('click', () => { if(div.classList.contains('minimized')) { div.classList.remove('minimized'); localStorage.setItem('gmvPanelMinimized', 'false'); } });
    
    // 退出
    const logoutBtn = div.querySelector('#btn-logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => { 
            e.stopPropagation(); 
            if(confirm("确认退出当前账号？")) { 
                chrome.storage.local.clear(() => { location.reload(); }); 
            }
        });
    }

    // 导入弹窗
    const importBtn = div.querySelector('#btn-import-trigger');
    if(importBtn) importBtn.addEventListener('click', (e) => { e.stopPropagation(); showImportModal(); });
}

// ==========================================
// 5. 核心逻辑：查询 + 强制入库
// ==========================================
async function fetchDataAndUpsert(uid, handle, scrapedEmail, metaData) {
    const cleanHandle = handle.replace('@', '');
    const apiUrl = `${SERVER_URL}/api/check?uid=${uid}&handle=${cleanHandle}&userId=${g_user.id}`;

    try {
        const res = await fetch(apiUrl);
        const data = await res.json();
        const backendHasEmail = (data.contact && data.contact !== '暂无' && data.contact !== null);

        if (!backendHasEmail && scrapedEmail) {
            console.log(`🚀 强制入库新邮箱: ${scrapedEmail}`);
            data.contact = scrapedEmail + " (新抓取)"; 
            await upsertEmailToSupabase(uid, cleanHandle, scrapedEmail);
        }

        if (metaData.followers && !data.followers) data.followers = metaData.followers;
        showDataPanel(data, handle, uid);

    } catch (err) {
        console.error("API请求失败:", err);
        showDataPanel({ found: false, contact: scrapedEmail }, handle, uid);
    }
}

async function upsertEmailToSupabase(uid, handle, email) {
    const url = `${SUPABASE_URL}/rest/v1/TIKTOKUS`; 
    try {
        await fetch(url, {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json',
                'apikey': SUPABASE_KEY,
                'Authorization': `Bearer ${SUPABASE_KEY}`,
                'Prefer': 'resolution=merge-duplicates'
            },
            body: JSON.stringify({ uid: uid, handle: handle, email: email, "带货分类": "自动抓取" })
        });
        console.log("✅ 数据库同步成功");
    } catch (e) { console.error("网络请求错误", e); }
}

// ==========================================
// 6. 抓取与清洗工具
// ==========================================
function cleanEmail(rawEmail) {
    if (!rawEmail) return null;
    let e = rawEmail.replace(/\\n/g, "").replace(/\n/g, "").replace(/\\t/g, "").replace(/\t/g, "").replace(/\\u002F/gi, "/").replace(/\\\//g, "/").trim();
    const match = e.match(EMAIL_REGEX);
    if (match && match[0]) {
        const finalEmail = match[0].toLowerCase();
        if (EXCLUDE_EMAILS.some(ex => finalEmail.includes(ex))) return null;
        if (finalEmail.includes('tiktok.com')) return null;
        return finalEmail;
    }
    return null;
}

function getTikTokMetaData() {
    let result = { uid: null, signatureEmail: null, followers: null };
    try {
        const script = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
        if (script) {
            const json = JSON.parse(script.textContent);
            const scope = json.__DEFAULT_SCOPE__;
            let userInfo = scope['webapp.user-detail']?.userInfo?.user || scope['webapp.video-detail']?.itemInfo?.itemStruct?.author;
            let stats = scope['webapp.user-detail']?.userInfo?.stats;

            if (userInfo) {
                result.uid = userInfo.id;
                if (userInfo.signature) {
                    const sigEmails = userInfo.signature.match(EMAIL_REGEX);
                    if (sigEmails) {
                        for (let raw of sigEmails) {
                            const cleaned = cleanEmail(raw);
                            if (cleaned) { result.signatureEmail = cleaned; break; }
                        }
                    }
                }
            }
            if (stats) result.followers = stats.followerCount;
        }
    } catch (e) {}
    if (!result.uid) {
        const m = document.body.innerHTML.match(/"authorId":"(\d+)"/) || document.body.innerHTML.match(/"ownerId":"(\d+)"/);
        if (m) result.uid = m[1];
    }
    return result;
}

function findEmailInBody() {
    try {
        const matches = document.body.innerText.match(EMAIL_REGEX);
        if (matches) {
            for (let raw of matches) {
                const cleaned = cleanEmail(raw);
                if (cleaned) return cleaned;
            }
        }
    } catch (e) {}
    return null;
}

// 等待页面完全加载后再启动，防止干扰 TikTok 渲染
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAuth);
} else {
    initAuth();
}